public class name{
    public static void main(String[] args){
        System.out.println("My name is Jang Singh");
        System.out.println("I am 20 years old");
        System.out.println("My hometown in Sacramento California");
    }
}