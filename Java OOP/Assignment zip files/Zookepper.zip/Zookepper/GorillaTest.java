public class GorillaTest{
    public static void main (String[] args){
        Gorilla gorilla = new Gorilla();
        gorilla.throwbanana();
        gorilla.throwbanana();
        gorilla.eatBananas();
        gorilla.climb();
    }
}