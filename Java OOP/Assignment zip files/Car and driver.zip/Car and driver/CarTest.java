public class CarTest {
    public static void main(String[] args){
    Driver drive = new Driver();
    Car car = new Car();
    drive.drive();
    // drive.drive();
    drive.drive();
    drive.drive();
    drive.boosters();
    drive.fuel();    
    // drive.fuel();    
    // drive.fuel();
    }
}