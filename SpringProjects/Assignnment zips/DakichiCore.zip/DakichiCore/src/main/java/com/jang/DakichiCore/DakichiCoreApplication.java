package com.jang.DakichiCore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DakichiCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(DakichiCoreApplication.class, args);
	}

}
