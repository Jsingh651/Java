package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DakichiPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DakichiPracticeApplication.class, args);
	}

}
