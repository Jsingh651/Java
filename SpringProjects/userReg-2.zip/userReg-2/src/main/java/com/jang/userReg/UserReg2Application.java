package com.jang.userReg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserReg2Application {

	public static void main(String[] args) {
		SpringApplication.run(UserReg2Application.class, args);
	}

}
