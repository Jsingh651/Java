package com.jang.userReg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserReg2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
