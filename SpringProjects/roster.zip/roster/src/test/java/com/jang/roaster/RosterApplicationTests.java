package com.jang.roaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RosterApplicationTests {

	@Test
	void contextLoads() {
	}

}
