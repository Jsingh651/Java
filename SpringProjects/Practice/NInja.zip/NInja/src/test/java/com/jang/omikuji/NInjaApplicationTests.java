package com.jang.omikuji;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NInjaApplicationTests {

	@Test
	void contextLoads() {
	}

}
